"residuals.cca" <-
function(object, ...) fitted(object, model = "CA", ...)

